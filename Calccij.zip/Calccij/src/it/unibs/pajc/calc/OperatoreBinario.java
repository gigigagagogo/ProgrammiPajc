package it.unibs.pajc.calc;

public interface OperatoreBinario {
	double eval(double a,double b);

}
